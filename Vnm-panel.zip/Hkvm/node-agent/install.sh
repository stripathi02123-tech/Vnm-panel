#!/bin/bash
# =====================================================================
# VNM Node Agent installer
# ---------------------------------------------------------------------
# Usage (run as root, from inside the extracted node-agent/ directory):
#   sudo ./install.sh --panel-url https://your-panel.example.com --token vnm_agent_...
#
# What it does:
#   - Creates a dedicated, unprivileged "vnm-agent" system user
#   - Installs Node.js if missing (Debian/Ubuntu apt only - if you're on
#     another distro, install Node 16+ yourself first and re-run)
#   - Copies the agent into /opt/vnm-agent
#   - Writes /etc/vnm-agent/agent.env with your panel URL + token
#     (the token is a per-node secret - this file is 600, root:vnm-agent)
#   - Installs and starts the systemd service (falls back to a plain
#     background `nohup` start with instructions if systemd isn't
#     available)
# =====================================================================
set -euo pipefail

PANEL_URL=""
AGENT_TOKEN=""
INSTALL_DIR="/opt/vnm-agent"
CONFIG_DIR="/etc/vnm-agent"
SERVICE_USER="vnm-agent"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --panel-url) PANEL_URL="$2"; shift 2 ;;
    --token) AGENT_TOKEN="$2"; shift 2 ;;
    *) echo "Unknown argument: $1"; exit 1 ;;
  esac
done

if [[ -z "$PANEL_URL" || -z "$AGENT_TOKEN" ]]; then
  echo "Usage: sudo ./install.sh --panel-url https://your-panel.example.com --token <token>"
  exit 1
fi

if [[ $EUID -ne 0 ]]; then
  echo "This installer must be run as root (sudo ./install.sh ...)"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Checking for Node.js..."
if ! command -v node >/dev/null 2>&1; then
  if command -v apt-get >/dev/null 2>&1; then
    echo "==> Installing Node.js via apt..."
    apt-get update -y
    apt-get install -y nodejs npm
  else
    echo "Node.js is not installed and this installer only knows how to install it via apt."
    echo "Install Node.js 16+ manually, then re-run this script."
    exit 1
  fi
fi
echo "==> Node.js: $(node --version)"

echo "==> Checking for QEMU/KVM (optional - only needed if this node will run VMs)..."
if command -v qemu-system-x86_64 >/dev/null 2>&1; then
  echo "    Found: $(qemu-system-x86_64 --version | head -n1)"
else
  echo "    Not found. File-manager and system-stats features will still work;"
  echo "    install qemu-system-x86 (and enable /dev/kvm) before assigning VMs to this node."
fi

echo "==> Creating service user '$SERVICE_USER'..."
if ! id -u "$SERVICE_USER" >/dev/null 2>&1; then
  useradd --system --home-dir "$INSTALL_DIR" --shell /usr/sbin/nologin "$SERVICE_USER"
fi

echo "==> Installing agent to $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR"
cp -r "$SCRIPT_DIR"/agent.js "$SCRIPT_DIR"/lib "$SCRIPT_DIR"/package.json "$INSTALL_DIR"/
cd "$INSTALL_DIR"
if command -v npm >/dev/null 2>&1; then
  npm install --omit=dev --no-audit --no-fund
fi
mkdir -p "$INSTALL_DIR/vms"
chown -R "$SERVICE_USER":"$SERVICE_USER" "$INSTALL_DIR"

echo "==> Writing config to $CONFIG_DIR/agent.env..."
mkdir -p "$CONFIG_DIR"
cat > "$CONFIG_DIR/agent.env" <<EOF
PANEL_URL=$PANEL_URL
AGENT_TOKEN=$AGENT_TOKEN
AGENT_VM_DIR=$INSTALL_DIR/vms
EOF
chown root:"$SERVICE_USER" "$CONFIG_DIR/agent.env"
chmod 640 "$CONFIG_DIR/agent.env"

if command -v systemctl >/dev/null 2>&1; then
  echo "==> Installing systemd service..."
  cp "$SCRIPT_DIR/vnm-agent.service" /etc/systemd/system/vnm-agent.service
  systemctl daemon-reload
  systemctl enable vnm-agent
  systemctl restart vnm-agent
  sleep 2
  systemctl --no-pager status vnm-agent || true
  echo ""
  echo "==> Done. Follow logs with:  journalctl -u vnm-agent -f"
else
  echo "==> systemd not found - starting the agent directly with nohup instead."
  echo "    You'll need to arrange for it to start on boot yourself."
  sudo -u "$SERVICE_USER" bash -c "cd $INSTALL_DIR && set -a && source $CONFIG_DIR/agent.env && set +a && nohup node agent.js > $INSTALL_DIR/agent.log 2>&1 &"
  echo "==> Done. Logs at $INSTALL_DIR/agent.log"
fi
