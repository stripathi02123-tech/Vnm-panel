# VNM Node Agent

Runs on a node (the same machine as the panel, for a **Local** node, or
a separate VPS, for a **Remote** node) and gives the VNM Panel real
access to that machine: live CPU/RAM/disk stats, VM start/stop/restart
via real QEMU, and file-manager operations against VM guest filesystems
over real SSH/SFTP.

The agent **dials out** to the panel over an authenticated WebSocket
(`wss://your-panel/agent-connect`) rather than the panel dialing in to
it. That means a node behind NAT or a firewall that only allows
outbound traffic still works fine, and the panel never needs inbound
network access into your node's network.

## Requirements

- Node.js 16+
- For VM hosting: `qemu-system-x86_64` (and `/dev/kvm` for hardware
  acceleration) - not required if this node will only run VMs whose
  disks live elsewhere, or if it's being added purely for its own sake
  before QEMU is installed
- Outbound HTTPS/WSS access to your panel

## Installing (Remote Node)

1. In the panel: **Admin → Nodes → Add Node → Remote**, name it, and
   click **Register**. You'll get a one-time install command that
   looks like:
   ```
   curl -fsSL -H "Authorization: Bearer <token>" \
     https://your-panel/api/nodes/agent-package -o vnm-agent.tar.gz \
     && tar xzf vnm-agent.tar.gz && cd node-agent \
     && sudo ./install.sh --panel-url https://your-panel --token <token>
   ```
2. Run it on the remote server as root (or with sudo).
3. The installer creates a dedicated `vnm-agent` system user, installs
   Node.js if missing (Debian/Ubuntu via apt - other distros: install
   Node 16+ yourself first), copies the agent to `/opt/vnm-agent`,
   writes `/etc/vnm-agent/agent.env`, and starts it via systemd
   (`vnm-agent.service`), enabled on boot.
4. Back in the panel, the node should flip to **Online** within about
   15 seconds (the agent's heartbeat interval).

## Installing (Local Node)

The panel already has a bootstrapped "Local Node" row the moment it
starts up, and for Local VMs it keeps using its existing direct QEMU/
SSH code paths - **you don't need to install this agent for Local
mode to work.** Only install it locally too if you specifically want
the Local node's stats/lifecycle to also go through the agent protocol
(e.g. for architecture consistency, or to test the agent without a
second server) - same install steps, just run `install.sh` on the
panel's own machine with `--panel-url http://127.0.0.1:<port>`.

## Configuration

Environment variables (or `/etc/vnm-agent/agent.env` when installed
via `install.sh`):

| Variable | Required | Description |
|---|---|---|
| `PANEL_URL` | yes | e.g. `https://panel.example.com` |
| `AGENT_TOKEN` | yes | Per-node secret issued when the node was registered |
| `AGENT_VM_DIR` | no | Where this node keeps VM disks/PID files (default `~/vms`) |
| `QEMU_BIN` | no | Override the `qemu-system-x86_64` path |
| `AGENT_HEARTBEAT_MS` | no | Heartbeat interval (default 15000) |
| `AGENT_SSH_CONNECT_TIMEOUT_MS` | no | Guest SSH connect timeout (default 15000) |
| `AGENT_SFTP_IDLE_MS` | no | Idle guest SFTP session timeout (default 600000) |

## Security notes

- The token is generated once by the panel and shown once at
  registration time. The panel stores only a SHA-256 **hash** of it
  (`nodes.agent_token_hash`) - if your panel database is ever read by
  someone else, they cannot recover a usable agent token from it. If a
  token is compromised, rotate it from **Admin → Nodes → (node) →
  Rotate Token**; the old token stops authenticating immediately.
- Every command the panel sends the agent travels over the same
  connection the agent authenticated with - there's no separate
  unauthenticated control channel.
- The agent never receives your panel's admin credentials, session
  cookies, or CSRF tokens - only its own per-node token.
- VM guest SSH credentials (username/password) are sent to the agent
  per-request, over that same authenticated connection, and are never
  persisted to disk by the agent - only held in memory for the
  duration of the SSH session (which is itself idle-timed-out).
- Run the agent as the dedicated unprivileged `vnm-agent` user the
  installer creates, not as root. It only needs write access to its
  own `AGENT_VM_DIR`.
- Use `https://`/`wss://` for `PANEL_URL` in production. Plain
  `http://`/`ws://` works (and is what this repo's own tests use
  against a local panel) but sends the token and file contents
  unencrypted - fine for `127.0.0.1`, not for the open internet.

## Agent protocol (for reference / troubleshooting)

Once connected and authenticated, the agent sends:
- `{"type":"heartbeat","stats":{...}}` every `AGENT_HEARTBEAT_MS`

...and responds to commands the panel sends:
- `{"type":"command","requestId":"...","action":"system.info","payload":{}}`
  → `{"type":"command-result","requestId":"...","result":{...}}` or
  `{"type":"command-error","requestId":"...","error":"..."}`

Actions implemented: `system.info`, `system.stats`, `vm.start`,
`vm.stop`, `vm.restart`, `vm.status`, `file.list`, `file.storage`,
`file.read`, `file.write`, `file.mkdir`, `file.createFile`,
`file.rename`, `file.delete`, `file.compress`, `file.extract`.

File upload/download use a small binary relay on the same socket
(control messages `upload-start`/`upload-end`/`download-start`, binary
frames tagged with an 8-byte request ID) so large files are streamed
in bounded-size chunks in both directions rather than buffered whole
in memory anywhere along the path.

## Troubleshooting

- **Node stays "Offline" in the panel** - check `journalctl -u
  vnm-agent -f` on the node. Most common causes: wrong `PANEL_URL`
  (must be reachable from the node), an expired/rotated token, or a
  firewall blocking outbound 443/80.
- **"QEMU is not available on this node"** when starting a VM - install
  `qemu-system-x86` (or `qemu-kvm`) on that node; this is an honest
  capability check, not a bug - the agent will never pretend a VM
  started when it didn't.
- **File manager says "Node is offline"** - the agent's WebSocket
  connection dropped; it auto-reconnects with backoff, check the
  agent's logs.
- **Re-run the installer** any time to update config or reinstall -
  it's safe to run more than once.
