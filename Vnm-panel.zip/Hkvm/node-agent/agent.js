#!/usr/bin/env node
// =====================================================================
// VNM Node Agent
// ---------------------------------------------------------------------
// Runs ON a node (local or remote) and gives the VNM Panel real access
// to that node's system: CPU/RAM/disk/KVM stats, VM start/stop/restart
// via real QEMU, and file-manager operations against VM guest
// filesystems over real SSH/SFTP.
//
// Connection model: the agent dials OUT to the panel's WebSocket
// endpoint (wss://panel-host/agent-connect) and authenticates with a
// per-node bearer token. This means a remote node behind NAT or a
// firewall that only allows outbound traffic still works, and the
// panel never needs inbound network access to the node. Once
// connected, the same socket carries heartbeats (agent -> panel) and
// commands + results (panel -> agent -> panel).
//
// Config is read from environment variables, or from a JSON config
// file (see loadFileConfig() below) written by install.sh for a
// systemd-managed install:
//   PANEL_URL     e.g. https://panel.example.com  (required)
//   AGENT_TOKEN   the per-node token issued by the panel (required)
//   AGENT_VM_DIR  where this node keeps VM disks/PIDs (default ~/vms)
//   QEMU_BIN      override the qemu-system-x86_64 path
// =====================================================================

const fs = require('fs');
const path = require('path');
const os = require('os');
const WebSocket = require('ws');

const systemInfo = require('./lib/system-info');
const sftpOps = require('./lib/sftp-ops');
const guestSsh = require('./lib/guest-ssh');
const qemu = require('./lib/qemu-launcher');

const AGENT_VERSION = require('./package.json').version;
const CONFIG_PATH = process.env.AGENT_CONFIG || '/etc/vnm-agent/config.json';

function loadFileConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  } catch (e) { console.warn(`[Agent] Could not read ${CONFIG_PATH}: ${e.message}`); }
  return {};
}

const fileConfig = loadFileConfig();
const PANEL_URL = process.env.PANEL_URL || fileConfig.panelUrl;
const AGENT_TOKEN = process.env.AGENT_TOKEN || fileConfig.token;
const HEARTBEAT_MS = parseInt(process.env.AGENT_HEARTBEAT_MS || '15000', 10);
const RECONNECT_BASE_MS = 2000;
const RECONNECT_MAX_MS = 30000;

if (!PANEL_URL || !AGENT_TOKEN) {
  console.error('[Agent] Missing PANEL_URL or AGENT_TOKEN (set as env vars, or in ' + CONFIG_PATH + '). See node-agent/README.md.');
  process.exit(1);
}

function wsUrl() {
  const u = new URL(PANEL_URL);
  u.protocol = u.protocol === 'https:' ? 'wss:' : 'ws:';
  u.pathname = (u.pathname.replace(/\/$/, '')) + '/agent-connect';
  return u.toString();
}

let ws = null;
let reconnectDelay = RECONNECT_BASE_MS;
let heartbeatTimer = null;
const activeTransfers = new Map(); // requestId -> { stream, kind }

function log(message) {
  const line = `[Agent] ${message}`;
  console.log(line);
  try { if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'log', message })); } catch (e) {}
}

function connect() {
  log(`Connecting to ${wsUrl()} ...`);
  ws = new WebSocket(wsUrl(), { headers: { Authorization: `Bearer ${AGENT_TOKEN}` } });

  ws.on('open', () => {
    reconnectDelay = RECONNECT_BASE_MS;
    console.log('[Agent] Connected to panel');
    startHeartbeat();
  });

  ws.on('message', (data, isBinary) => {
    if (isBinary) return handleTransferChunk(data);
    let msg;
    try { msg = JSON.parse(data.toString()); } catch (e) { return; }
    handleControlMessage(msg).catch((e) => console.error('[Agent] handler error:', e));
  });

  ws.on('close', () => {
    console.warn('[Agent] Disconnected from panel - reconnecting soon');
    stopHeartbeat();
    scheduleReconnect();
  });
  ws.on('error', (e) => console.error('[Agent] Socket error:', e.message));
}

function scheduleReconnect() {
  setTimeout(connect, reconnectDelay);
  reconnectDelay = Math.min(reconnectDelay * 1.7, RECONNECT_MAX_MS);
}

function startHeartbeat() {
  stopHeartbeat();
  const beat = async () => {
    try {
      const stats = await systemInfo.getLiveStats(qemu.VM_DIR);
      send({ type: 'heartbeat', agentVersion: AGENT_VERSION, stats });
    } catch (e) { console.error('[Agent] heartbeat failed:', e.message); }
  };
  beat();
  heartbeatTimer = setInterval(beat, HEARTBEAT_MS);
}
function stopHeartbeat() { if (heartbeatTimer) clearInterval(heartbeatTimer); heartbeatTimer = null; }

function send(obj) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}
function sendBinary(requestId, buf) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(Buffer.concat([Buffer.from(requestId.padEnd(8, ' ').slice(0, 8)), buf]));
}

// ---------------------------------------------------------------
// Command dispatch (panel -> agent JSON request/response)
// ---------------------------------------------------------------
const ACTIONS = {
  'system.info': async () => systemInfo.getSystemInfo(qemu.VM_DIR),
  'system.stats': async () => systemInfo.getLiveStats(qemu.VM_DIR),

  'vm.start': async (payload) => qemu.startVM(payload.vm),
  'vm.stop': async (payload) => qemu.stopVM(payload.vm),
  'vm.restart': async (payload) => qemu.restartVM(payload.vm),
  'vm.status': async (payload) => qemu.statusVM(payload.vm),

  'file.list': async (payload) => withSftp(payload, (ctx) => sftpOps.listDirectory(ctx, payload)),
  'file.storage': async (payload) => withSftp(payload, (ctx) => sftpOps.getStorage(ctx)),
  'file.read': async (payload) => withSftp(payload, (ctx) => sftpOps.readTextFile(ctx, payload.path, payload.maxBytes)),
  'file.stat': async (payload) => withSftp(payload, (ctx) => sftpOps.statFile(ctx, payload.path)),
  'file.write': async (payload) => withSftp(payload, (ctx) => sftpOps.writeTextFile(ctx, payload.path, payload.content, payload.maxBytes)),
  'file.mkdir': async (payload) => withSftp(payload, (ctx) => sftpOps.createFolder(ctx, payload.path, payload.name)),
  'file.createFile': async (payload) => withSftp(payload, (ctx) => sftpOps.createFile(ctx, payload.path, payload.name)),
  'file.rename': async (payload) => withSftp(payload, (ctx) => sftpOps.renamePath(ctx, payload.path, payload)),
  'file.delete': async (payload) => withSftp(payload, (ctx) => sftpOps.deletePaths(ctx, undefined, payload.paths)),
  'file.compress': async (payload) => withSftp(payload, (ctx) => sftpOps.compress(ctx, payload.path, payload.names, payload.archiveName, payload.format)),
  'file.extract': async (payload) => withSftp(payload, (ctx) => sftpOps.extract(ctx, payload.path, payload.archiveName, payload.destName))
};

async function withSftp(payload, fn) {
  const ctx = await guestSsh.getSession(payload.vmConn);
  return fn(ctx);
}

async function handleControlMessage(msg) {
  if (msg.type === 'command') return handleCommand(msg);
  if (msg.type === 'upload-start') return handleUploadStart(msg);
  if (msg.type === 'upload-end') return handleUploadEnd(msg);
  if (msg.type === 'upload-abort') return handleUploadAbort(msg);
  if (msg.type === 'download-start') return handleDownloadStart(msg);
}

async function handleCommand(msg) {
  const handler = ACTIONS[msg.action];
  if (!handler) {
    return send({ type: 'command-error', requestId: msg.requestId, error: `Unknown action: ${msg.action}` });
  }
  try {
    const result = await handler(msg.payload || {});
    send({ type: 'command-result', requestId: msg.requestId, result });
  } catch (e) {
    send({ type: 'command-error', requestId: msg.requestId, error: e.message, httpStatus: e.httpStatus, code: e.code });
  }
}

// ---------------------------------------------------------------
// Upload relay (panel -> agent binary chunks -> guest SFTP write)
// ---------------------------------------------------------------
async function handleUploadStart(msg) {
  try {
    const ctx = await guestSsh.getSession(msg.vmConn);
    const safeName = sftpOps.assertSafeName(msg.filename, 'File name');
    const remotePath = sftpOps.joinRemotePath(msg.targetDir, safeName);
    const writeStream = ctx.sftp.createWriteStream(remotePath);
    let bytes = 0;
    let limitHit = false;
    writeStream.on('error', (err) => {
      send({ type: 'transfer-error', requestId: msg.requestId, error: 'Upload failed: ' + err.message });
      activeTransfers.delete(msg.requestId);
    });
    activeTransfers.set(msg.requestId, {
      kind: 'upload', stream: writeStream, remotePath,
      onChunk: (buf) => {
        bytes += buf.length;
        if (msg.maxBytes && bytes > msg.maxBytes && !limitHit) {
          limitHit = true;
          writeStream.destroy();
          send({ type: 'transfer-error', requestId: msg.requestId, error: 'File exceeds the upload size limit', code: 'TOO_LARGE', httpStatus: 413 });
          activeTransfers.delete(msg.requestId);
          return;
        }
        if (!limitHit) writeStream.write(buf);
      }
    });
  } catch (e) {
    send({ type: 'transfer-error', requestId: msg.requestId, error: e.message, httpStatus: e.httpStatus });
  }
}
function handleTransferChunk(data) {
  const requestId = data.slice(0, 8).toString('utf8').trim();
  const payload = data.slice(8);
  const t = activeTransfers.get(requestId);
  if (t && t.onChunk) t.onChunk(payload);
}
function handleUploadEnd(msg) {
  const t = activeTransfers.get(msg.requestId);
  if (!t) return;
  t.stream.end(() => {
    send({ type: 'transfer-done', requestId: msg.requestId, result: { success: true, path: t.remotePath } });
    activeTransfers.delete(msg.requestId);
  });
}
function handleUploadAbort(msg) {
  const t = activeTransfers.get(msg.requestId);
  if (!t) return;
  try { t.stream.destroy(); } catch (e) {}
  activeTransfers.delete(msg.requestId);
}

// ---------------------------------------------------------------
// Download relay (guest SFTP read -> agent binary chunks -> panel)
// ---------------------------------------------------------------
async function handleDownloadStart(msg) {
  try {
    const ctx = await guestSsh.getSession(msg.vmConn);
    const info = await sftpOps.statFile(ctx, msg.path);
    const readStream = ctx.sftp.createReadStream(info.path);
    activeTransfers.set(msg.requestId, { kind: 'download', stream: readStream });
    readStream.on('data', (chunk) => sendBinary(msg.requestId, chunk));
    readStream.on('error', (err) => {
      send({ type: 'transfer-error', requestId: msg.requestId, error: 'Download failed: ' + err.message });
      activeTransfers.delete(msg.requestId);
    });
    readStream.on('end', () => {
      send({ type: 'transfer-done', requestId: msg.requestId, result: { size: info.size } });
      activeTransfers.delete(msg.requestId);
    });
  } catch (e) {
    send({ type: 'transfer-error', requestId: msg.requestId, error: e.message, httpStatus: e.httpStatus });
  }
}

console.log(`[Agent] VNM Node Agent v${AGENT_VERSION} starting (pid ${process.pid})`);
console.log(`[Agent] Panel: ${PANEL_URL}`);
console.log(`[Agent] VM directory: ${qemu.VM_DIR}`);
connect();

process.on('SIGTERM', () => { console.log('[Agent] Shutting down'); if (ws) ws.close(); process.exit(0); });
process.on('SIGINT', () => { console.log('[Agent] Shutting down'); if (ws) ws.close(); process.exit(0); });
