# Node Agent Architecture — what was added

Adds Local/Remote node support on top of the existing panel without
rewriting it: the panel's existing local VM/QEMU/SSH code paths are
**untouched**; a new node abstraction routes only Remote-node VM and
file-manager operations through a new standalone Node Agent.

## New files
- `system-info.js` — real CPU/RAM/disk/KVM/QEMU detection (no fake
  values), shared by the panel (Local Node) and the agent (Remote
  nodes) so both are measured identically.
- `sftp-ops.js` — the file-manager's connection-agnostic operation
  logic (list/upload/download/mkdir/save/rename/delete/compress/
  extract/storage), extracted so the panel and the agent share one
  implementation instead of two copies drifting apart.
- `nodes.js` — the node abstraction: `nodes` table bootstrap, per-node
  token auth (SHA-256 hash stored, plaintext shown once at
  registration), and the agent WebSocket manager (heartbeat, offline
  detection, JSON command relay, chunked binary upload/download relay).
- `node-agent/` — the standalone agent, deployed separately from the
  panel:
  - `agent.js` — connects out to the panel, authenticates, heartbeats,
    dispatches relayed commands
  - `lib/qemu-launcher.js` — real VM start/stop/restart (spawns actual
    `qemu-system-x86_64`, honest capability-gated - never fakes success)
  - `lib/guest-ssh.js` — guest VM SSH/SFTP session cache
  - `lib/system-info.js`, `lib/sftp-ops.js` — synced copies of the
    panel root modules (the agent ships as its own deployable package)
  - `package.json`, `install.sh`, `vnm-agent.service`, `README.md`
- `views/admin/nodes.ejs` — Admin → Nodes page: node cards with live
  CPU/RAM/disk/KVM, Add Node flow, install-command display, Test Node
  health check, token rotation, delete.

## Changed files
- `app.js`:
  - DB migration: `nodes` table + `vms.node_id` column (additive,
    existing `missingColumns` pattern), Local Node bootstrap on boot
  - `/agent-connect` WS branch (agent auth + heartbeat + command relay)
    and `/nodes-watch` WS branch (live updates for the Admin Nodes page)
  - `/api/nodes` (list/create/delete/rotate-token/test), `/api/nodes/
    agent-package` (tarball download), `/api/vms/:id/node` (reassign a
    VM's node), `/admin/nodes` page route
  - VM start/stop/restart: each now looks up the VM's node first. If
    remote, the request is delegated to that node's agent and returns.
    **If local (the default for every existing VM), execution falls
    straight through to the exact same code that ran before this
    change** - nothing in the local QEMU spawn/kill/PID-file logic was
    modified.
- `filemanager.js`: added a node-resolution middleware right after
  the existing VM-ownership check. Local VMs fall through unchanged to
  the exact same routes tested in the earlier File Manager work. Remote
  VMs are fully handled by a new relay function that talks to the
  agent instead of opening an SSH session directly.
- `views/partials/admin/sidebar.ejs`: added a "Nodes" nav entry.

## How authentication works
- A per-node token is generated once at registration
  (`vnm_agent_<id>_<32 random hex bytes>`) and shown once. The panel
  stores only `SHA-256(token)` in `nodes.agent_token_hash` - never the
  plaintext - so a database read alone can't recover a usable token.
- The **agent dials out** to the panel's WebSocket (not the other way
  around), presenting the token in its `Authorization` header. This
  means Remote nodes work fine behind NAT/firewalls with only outbound
  access, and the panel never needs inbound network access into a
  remote node's network - directly satisfying "remote node must not
  depend on the panel's localhost."
- Once connected, that same authenticated socket carries heartbeats
  and all relayed VM/file commands - there's no second, separately
  authenticated channel to worry about.
- Guest VM SSH credentials are sent to the agent per-request (over that
  authenticated connection) and never written to disk by the agent -
  only held for the life of the SSH session, which is itself
  idle-timed-out.

## Known, intentional scope boundaries
- **VM creation on a Remote node isn't wired up yet.** New VMs still
  target the Local Node by default. Reassigning an existing VM's
  routing to a Remote node works today via `PUT /api/vms/:id/node`
  (tested), but there's no UI button for it yet, and this does **not**
  migrate the VM's actual disk file onto the remote node's filesystem -
  that's disk-provisioning-on-a-remote-host, a separate, larger feature
  than "route this VM's operations to its node."
- The agent's QEMU launcher (`node-agent/lib/qemu-launcher.js`) covers
  the core config every VM needs (memory, CPU, root disk, NAT/bridge
  networking, optional ISO, serial console) but doesn't yet mirror
  every advanced option the panel's local launcher supports
  (cloud-init seed ISO staging, custom SMBIOS fields, per-VM extra QEMU
  args). Extending `buildArgs()` there is straightforward when needed -
  nothing about the surrounding process/PID-file/stop machinery has to
  change to add them.
- Command relay timeout is 20s by default (30s for VM start/restart);
  large/slow remote operations beyond that will time out cleanly with
  a clear error rather than hang.

## Tested end-to-end (real processes, not mocked)
Ran the actual `node-agent/agent.js` as a separate process against the
actual running panel, using a real local sshd standing in for a guest
VM (same setup proven in the earlier File Manager work):
1. Local Node bootstraps on boot with real CPU/RAM/disk/KVM values
2. Register a Remote node → token issued → `agent-package` tarball
   downloads correctly using only the node token (no admin session)
3. Real agent process connects, authenticates, and heartbeats real
   stats from the host it's running on
4. "Test Node" health check round-trips a real command through the
   authenticated tunnel (reachable / auth / filesystem / QEMU / KVM /
   VM subsystem all reported honestly)
5. File Manager through the remote relay: list, upload, download,
   mkdir, recursive delete - all verified against the real filesystem
   over SSH (found and fixed a race condition where a successful
   relayed upload could report failure; confirmed fixed)
6. VM start routed to a Remote node correctly fails honestly with
   `QEMU_UNAVAILABLE` (this sandbox has no KVM/QEMU - the same honest
   capability gating the panel already uses locally)
7. **The same VM start on a Local-node VM goes through the original,
   unmodified local code path** - confirmed by its distinct error
   shape/message, proving the routing change didn't touch it
8. Killing the agent process flips the node to Offline within ~3s
   (heartbeat-timeout detection), and in-flight file-manager requests
   for VMs on that node correctly return `NODE_OFFLINE` instead of
   hanging
9. Full regression pass of the original (local-VM) File Manager
   end-to-end test suite from the earlier session - identical results,
   confirming zero behavioral change to the existing feature
10. `/admin/nodes` page render (found and fixed a bug: the route was
    registered before the middleware that supplies `siteLogo`/
    `siteName` to every view, causing a 500 - moved it next to the
    other admin page routes; confirmed fixed, renders 200)

Not testable in this sandbox: an actual VM successfully booting via
the agent's QEMU launcher, since the sandbox has no `/dev/kvm` or
`qemu-system-x86_64` - the honest failure path in test 6/7 above is
the correct, intentional behavior for that situation, not a limitation
of the code.
