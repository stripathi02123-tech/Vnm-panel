#!/usr/bin/env bash
#
# VNM Panel - Installer
# Debian/Ubuntu only. Run as root (or with sudo):
#   sudo bash install.sh
#
# What this does:
#   1. Installs system dependencies (Node.js, QEMU/KVM, build tools)
#   2. Copies the panel into an install directory (default /opt/vnm-panel)
#   3. Installs npm dependencies
#   4. Generates a real .env (random SESSION_SECRET, chosen port)
#   5. Creates a systemd service so the panel survives reboots/crashes
#   6. Starts the service and prints next steps
#
set -euo pipefail

# ---------------------------------------------------------------------------
# Config (override via environment variables before running, e.g.
#   INSTALL_DIR=/srv/vnm PORT=9090 sudo -E bash install.sh
# ---------------------------------------------------------------------------
INSTALL_DIR="${INSTALL_DIR:-/opt/vnm-panel}"
SERVICE_NAME="${SERVICE_NAME:-vnm-panel}"
PANEL_PORT="${PORT:-8080}"
SERVICE_USER="${SERVICE_USER:-vnm}"
NODE_MAJOR="${NODE_MAJOR:-20}"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
c_green() { printf '\033[32m%s\033[0m\n' "$1"; }
c_yellow() { printf '\033[33m%s\033[0m\n' "$1"; }
c_red() { printf '\033[31m%s\033[0m\n' "$1"; }
step() { printf '\n\033[36m==> %s\033[0m\n' "$1"; }

require_root() {
  if [[ "${EUID}" -ne 0 ]]; then
    c_red "Please run this installer as root (sudo bash install.sh)."
    exit 1
  fi
}

require_supported_os() {
  if [[ ! -f /etc/os-release ]]; then
    c_red "Unsupported OS: /etc/os-release not found."
    exit 1
  fi
  # shellcheck disable=SC1091
  source /etc/os-release
  case "${ID:-}" in
    ubuntu|debian) ;;
    *)
      c_red "This installer supports Ubuntu/Debian only (detected: ${ID:-unknown})."
      exit 1
      ;;
  esac
}

# ---------------------------------------------------------------------------
# 1. Pre-flight checks
# ---------------------------------------------------------------------------
require_root
require_supported_os

step "Updating package index"
apt-get update -y

step "Installing system dependencies (build tools, sqlite, qemu/kvm)"
apt-get install -y \
  curl ca-certificates gnupg \
  build-essential python3 \
  sqlite3 libsqlite3-dev \
  qemu-system-x86 qemu-utils \
  bridge-utils net-tools \
  unzip git rsync

# ---------------------------------------------------------------------------
# 2. Node.js
# ---------------------------------------------------------------------------
step "Checking Node.js"
NEED_NODE_INSTALL=1
if command -v node >/dev/null 2>&1; then
  CURRENT_NODE_MAJOR="$(node -v | sed -E 's/^v([0-9]+).*/\1/')"
  if [[ "${CURRENT_NODE_MAJOR}" -ge "${NODE_MAJOR}" ]]; then
    NEED_NODE_INSTALL=0
    c_green "Node.js $(node -v) already installed - skipping."
  fi
fi

if [[ "${NEED_NODE_INSTALL}" -eq 1 ]]; then
  step "Installing Node.js ${NODE_MAJOR}.x via NodeSource"
  curl -fsSL "https://deb.nodesource.com/setup_${NODE_MAJOR}.x" | bash -
  apt-get install -y nodejs
fi

node -v
npm -v

# ---------------------------------------------------------------------------
# 3. KVM availability check (non-fatal - the panel falls back to software
#    emulation automatically if /dev/kvm isn't usable, e.g. inside another VM
#    without nested virtualization).
# ---------------------------------------------------------------------------
step "Checking for hardware virtualization (KVM)"
if [[ -e /dev/kvm ]] && [[ -r /dev/kvm ]] && [[ -w /dev/kvm ]]; then
  c_green "/dev/kvm is present and accessible - VMs will use hardware acceleration."
else
  c_yellow "/dev/kvm not accessible on this host. VMs will still work but will run"
  c_yellow "under software emulation (much slower). This is expected on nested"
  c_yellow "virtualization without KVM passthrough, or if your CPU/BIOS doesn't"
  c_yellow "expose VT-x/AMD-V. If you expect KVM to work, check:"
  c_yellow "  egrep -c '(vmx|svm)' /proc/cpuinfo   # should be > 0"
  c_yellow "  kvm-ok                               # (install cpu-checker)"
fi

# ---------------------------------------------------------------------------
# 4. Service user
# ---------------------------------------------------------------------------
step "Setting up service user '${SERVICE_USER}'"
if ! id -u "${SERVICE_USER}" >/dev/null 2>&1; then
  useradd --system --create-home --shell /usr/sbin/nologin "${SERVICE_USER}"
  c_green "Created system user: ${SERVICE_USER}"
else
  c_green "User ${SERVICE_USER} already exists - reusing."
fi
# QEMU needs to open /dev/kvm; kvm group grants that without running as root.
if getent group kvm >/dev/null 2>&1; then
  usermod -aG kvm "${SERVICE_USER}"
fi

# ---------------------------------------------------------------------------
# 5. Copy the panel into the install directory
# ---------------------------------------------------------------------------
step "Installing panel files to ${INSTALL_DIR}"
mkdir -p "${INSTALL_DIR}"
# Copy everything except node_modules (freshly installed below) and any
# existing runtime data (so re-running the installer never clobbers a
# working database).
rsync -a --delete \
  --exclude 'node_modules' \
  --exclude 'data' \
  --exclude '.env' \
  --exclude 'install.sh' \
  "${SOURCE_DIR}/" "${INSTALL_DIR}/"

mkdir -p "${INSTALL_DIR}/data"

# ---------------------------------------------------------------------------
# 6. .env - generate one if it doesn't already exist (never overwrite an
#    existing config on re-install/upgrade runs)
# ---------------------------------------------------------------------------
step "Writing configuration"
ENV_FILE="${INSTALL_DIR}/.env"
if [[ -f "${ENV_FILE}" ]]; then
  c_yellow "Existing .env found at ${ENV_FILE} - leaving it untouched."
else
  SESSION_SECRET="$(node -e 'console.log(require("crypto").randomBytes(32).toString("hex"))')"
  cat > "${ENV_FILE}" <<EOF
# VNM Panel
PORT=${PANEL_PORT}
VNM_DATA_DIR=${INSTALL_DIR}/data
PANEL_NAME=VNM
DEFAULT_LOGO_URL=/images/logo.png
NODE_ENV=production
SESSION_SECRET=${SESSION_SECRET}
EOF
  c_green "Generated new .env with a random SESSION_SECRET."
fi

# ---------------------------------------------------------------------------
# 7. npm install (production deps only)
# ---------------------------------------------------------------------------
step "Installing npm dependencies (this can take a minute)"
(cd "${INSTALL_DIR}" && npm install --omit=dev)

# ---------------------------------------------------------------------------
# 8. Permissions
# ---------------------------------------------------------------------------
step "Fixing ownership"
chown -R "${SERVICE_USER}:${SERVICE_USER}" "${INSTALL_DIR}"
chmod 600 "${ENV_FILE}"

# ---------------------------------------------------------------------------
# 9. systemd service
# ---------------------------------------------------------------------------
step "Installing systemd service"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
cat > "${SERVICE_FILE}" <<EOF
[Unit]
Description=VNM Panel - VM Management Panel
After=network.target

[Service]
Type=simple
User=${SERVICE_USER}
Group=${SERVICE_USER}
WorkingDirectory=${INSTALL_DIR}
EnvironmentFile=${INSTALL_DIR}/.env
ExecStart=$(command -v node) ${INSTALL_DIR}/app.js
Restart=on-failure
RestartSec=3
# QEMU child processes need real device access, not a fully locked-down unit.
NoNewPrivileges=true
ProtectSystem=full
ReadWritePaths=${INSTALL_DIR}

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "${SERVICE_NAME}"
systemctl restart "${SERVICE_NAME}"

# ---------------------------------------------------------------------------
# 10. Wait briefly and report status
# ---------------------------------------------------------------------------
step "Checking service status"
sleep 2
if systemctl is-active --quiet "${SERVICE_NAME}"; then
  c_green "VNM Panel is running."
else
  c_red "VNM Panel failed to start. Recent logs:"
  journalctl -u "${SERVICE_NAME}" --no-pager -n 40
  exit 1
fi

SERVER_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
step "Done"
cat <<EOF

VNM Panel installed.

  Install dir : ${INSTALL_DIR}
  Config      : ${ENV_FILE}
  Service     : systemctl {status|restart|stop} ${SERVICE_NAME}
  Logs        : journalctl -u ${SERVICE_NAME} -f
  URL         : http://${SERVER_IP:-<your-server-ip>}:${PANEL_PORT}

A default admin account is created on first run - check the service logs
for the generated username/password:

  journalctl -u ${SERVICE_NAME} -n 100 | grep -A2 "Default admin"

Log in and change that password immediately.
EOF
